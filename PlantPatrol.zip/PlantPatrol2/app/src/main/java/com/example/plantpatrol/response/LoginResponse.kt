package com.example.plantpatrol.response

data class User(
    val id: Int,
    val name: String,
    val email: String,
    val age: Int,
    val gender: String,
    val password: String,
    val role: String,
    val createdAt: String,
    val updatedAt: String
)

data class LoginResponseData(
    val user: User,
    val token: String
)

data class LoginResponse(
    val success: Boolean,
    val message: String,
    val data: LoginResponseData
)