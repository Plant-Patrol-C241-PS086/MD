package com.example.plantpatrol.adapter

data class Obat(
    val nama: String,
    val kategori: String,
)
