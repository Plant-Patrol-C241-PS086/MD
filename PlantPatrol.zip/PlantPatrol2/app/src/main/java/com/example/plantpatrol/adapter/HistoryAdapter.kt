package com.example.plantpatrol.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.plantpatrol.R
import com.example.plantpatrol.ui.bookmark.HistoryViewHolder

class HistoryAdapter(private val historyList: List<HistoryItem>) :
    RecyclerView.Adapter<HistoryViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HistoryViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.fragment_bookmark, parent, false) // Use the correct layout file
        return HistoryViewHolder(itemView)
    }
//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HistoryViewHolder {
//        val itemView = LayoutInflater.from(parent.context)
//            .inflate(R.recycler_view_history, parent, false)
//        return HistoryViewHolder(itemView)
//    }

    override fun onBindViewHolder(holder: HistoryViewHolder, position: Int) {
        val historyItem = historyList[position]
        holder.titleTextView.text = historyItem.title
        holder.detailTextView.text = historyItem.detail
    }

    override fun getItemCount(): Int {
        return historyList.size
    }
}