package com.example.plantpatrol.response

data class PredictResponse(
    val obat: String,
    val predicted_label: String
)
