package com.example.plantpatrol.ui.cart

import ObatAdapter
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.appcompat.widget.SearchView
import com.example.plantpatrol.R
import com.example.plantpatrol.adapter.Obat

class SearchActivity : AppCompatActivity() {

    private lateinit var searchView: SearchView
    private lateinit var recyclerView: RecyclerView
    private lateinit var obatAdapter: ObatAdapter
    private val obatList = mutableListOf<Obat>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_cart)

        initViews()
        initData()
        initRecyclerView()
        setupSearchView()
    }

    private fun initViews() {
        searchView = findViewById(R.id.search_view)
        recyclerView = findViewById(R.id.recycler_view)
    }

    private fun initData() {
        // Inisialisasi data obat dari sumber data (API, database, dll.)
        // Contoh data obat
        val obat1 = Obat("Paracetamol", "Analgesik")
        val obat2 = Obat("Ibuprofen", "Antiinflamasi Nonsteroid")
        val obat3 = Obat("Amoxicillin", "Antibiotik")
        obatList.addAll(listOf(obat1, obat2, obat3))
    }

    private fun initRecyclerView() {
        obatAdapter = ObatAdapter(obatList)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = obatAdapter
    }

    private fun setupSearchView() {
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextChange(query: String): Boolean {
                filterObat(query)
                return false
            }

            override fun onQueryTextSubmit(query: String): Boolean {
                return false
            }
        })
    }

    private fun filterObat(query: String) {
        val filteredObat = obatList.filter {
            it.nama.toLowerCase().contains(query.toLowerCase()) ||
                    it.kategori.toLowerCase().contains(query.toLowerCase())
        }
        //obatAdapter.updateObatList(filteredObat)
    }
}
