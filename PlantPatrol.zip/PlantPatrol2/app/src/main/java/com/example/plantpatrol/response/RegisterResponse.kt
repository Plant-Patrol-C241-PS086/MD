package com.example.plantpatrol.data

data class RegisterResponseData(
    val id: Int,
    val name: String,
    val email: String,
    val password: String,
    val age: String,
    val gender: String,
    val role: String,
    val updatedAt: String,
    val createdAt: String
)

data class RegisterResponse(
    val success: Boolean,
    val message: String,
    val data: RegisterResponseData
)
