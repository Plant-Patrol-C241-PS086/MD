package com.example.plantpatrol.adapter

class HistoryItem(val detail: CharSequence?, val title: CharSequence?) {
    val historyItem = HistoryItem("Some details", "History Title")
    // You can leave the class body empty since you're initializing
    // the properties in the constructor
}