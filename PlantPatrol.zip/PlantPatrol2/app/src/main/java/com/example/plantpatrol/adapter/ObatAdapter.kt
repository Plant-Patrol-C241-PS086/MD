import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.plantpatrol.R
import com.example.plantpatrol.adapter.Obat

class ObatAdapter(private val obatList: List<Obat>) :
    RecyclerView.Adapter<ObatAdapter.ObatViewHolder>() {

    class ObatViewHolder(itemView: ViewGroup) : RecyclerView.ViewHolder(itemView) {
        val namaTextView: TextView = itemView.findViewById(R.id.nama_text_view)
//        val kategoriTextView: TextView = itemView.findViewById(R.id.kategori_text_view)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ObatViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.fragment_cart, parent, false)
        return ObatViewHolder(itemView as ViewGroup)
    }

    override fun onBindViewHolder(holder: ObatViewHolder, position: Int) {
        val obat = obatList[position]
        holder.namaTextView.text = obat.nama
//        holder.kategoriTextView.text = obat.kategori
    }

    override fun getItemCount(): Int = obatList.size

//    fun updateObatList(filteredObat: List<Obat>) {
//        submitList(filteredObat)
////        obatList.clear()
////        obatList.addAll(filteredObat)
//        notifyDataSetChanged()
//    }
}
