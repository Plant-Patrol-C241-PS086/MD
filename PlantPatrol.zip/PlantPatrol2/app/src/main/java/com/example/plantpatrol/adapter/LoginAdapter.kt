package com.example.plantpatrol.adapter

class LoginAdapter {
}