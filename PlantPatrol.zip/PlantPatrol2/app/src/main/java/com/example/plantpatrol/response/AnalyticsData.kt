package com.example.plantpatrol.response

data class AnalyticsData(
    val activeUsers: Int,
    val totalUsers: Int,
)