package com.example.plantpatrol.ui.bookmark

import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.plantpatrol.R

class HistoryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    val titleTextView: TextView = itemView.findViewById(R.id.text_view_title)
    val detailTextView: TextView = itemView.findViewById(R.id.text_view_detail)
}